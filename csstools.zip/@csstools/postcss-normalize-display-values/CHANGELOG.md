# Changes to PostCSS Normalize Display Values

### 1.0.0 

- Initial version
