# Changes to PostCSS HWB Function

### 1.0.01 (May 18, 2022)

- Fix grayscale conversions.

### 1.0.0 (January 22, 2022)

- Initial version
