# Changes to PostCSS Stepped Value Functions

### 1.0.0 (May 2, 2022)

- Initial version
